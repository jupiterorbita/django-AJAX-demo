from django.apps import AppConfig


class AjaxdemoConfig(AppConfig):
    name = 'ajaxdemo'
